This module is an implementation of the basic machine learning algorithm
that are well described today. The implementation of each module is meant 
to stay simple, to allow the aspiring machine learning student to understand
the implementation of such algorithms.